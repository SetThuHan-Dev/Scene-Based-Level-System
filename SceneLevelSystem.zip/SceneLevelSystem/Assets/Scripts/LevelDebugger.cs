using UnityEngine;
using UnityEngine.UI;
using Sabresaurus.PlayerPrefsUtilities;
using UnityEngine.SceneManagement;

public class LevelDebugger : MonoBehaviour
{
    [SerializeField] private InputField inputField;
    [SerializeField] private int levelNum;

    public void GoTo()
    {
        levelNum = int.Parse(inputField.text);
        PlayerPrefsUtility.SetEncryptedInt("LEVEL", levelNum);
        PlayerPrefsUtility.SetEncryptedBool("LevelLoaded", false);

        if(levelNum > 10) // Max Level
        {
            PlayerPrefsUtility.SetEncryptedBool("IsGenerated", false);
        }
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
 
}
